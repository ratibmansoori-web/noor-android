# Noor Android (test APK)

Ye project aap ki Noor website se ek Android app (APK) banata hai jo **namaz ke theek waqt par azan ki awaaz** baja sakti hai, app band hone par bhi.
APK GitHub par free mein banti hai. Aap ko computer par kuch install nahi karna.

## Pehle ye check karein
APK aap ki **live Noor website** se files uthati hai. Isliye pehle Cloudflare par **sabse naya zip (v34 ya usse naya)** upload hona chahiye.
Check: `https://ramzan-app.pages.dev` kholein, neeche "Version 34" dikhna chahiye.
(Agar aap ki website ka address alag hai, to `build.mjs` ki 7 number wali line (`const SITE = ...`) mein address badal dein.)

## Steps
1. **github.com** par free account banayein aur login karein.
2. Upar **+**, phir **New repository**. Naam `noor-android`, **Private** rakhein, **Create repository**.
3. **Files upload karein**
   - **Phone par:** is zip ko Files app mein **Extract** karein. GitHub mein **Add file, phir Upload files** dabayein aur ye 4 files chunein: `package.json`, `capacitor.config.json`, `native.js`, `build.mjs`. Neeche **Commit changes**.
     Phir **Add file, phir Create new file**. Naam ke khane mein ye likhein: `.github/workflows/build-apk.yml` (`/` likhne se folder khud ban jate hain). Zip ke andar wali `build-apk.yml` ka poora text copy karke paste karein. **Commit changes**.
   - **Computer par:** zip unzip karke saari cheezein (`.github` folder sahit) "uploading an existing file" mein drag-drop karein, phir Commit.
4. Upar **Actions** tab kholein (agar poochhe to "I understand my workflows, enable them" dabayein). Left mein **Build Noor APK**, phir **Run workflow**, phir hara **Run workflow** button.
5. 5 se 10 minute rukein. Hara ✅ aaye to run par click karein. Neeche **Artifacts** mein **Noor-APK** milega. Use download karke unzip karein, andar `app-debug.apk` hai.
6. Phone mein `app-debug.apk` kholein. "Install unknown apps" allow karein aur install karein.

## Test (5 minute)
1. Noor kholein, **🔔 Azan alert** kholein. Sabse upar naya card **"📲 फ़ोन अलार्म (अज़ान)"** dikhega.
2. Switch **ON** karein aur notification ki **Allow** dabayein. Agar "exact alarm" ki screen khule to Noor ko Allow karein, wapas aakar switch dobara ON karein.
3. **"10 सेकंड बाद टेस्ट अज़ान"** dabayein, phir app ko recent apps se band kar dein. 10 second mein azan baje.
4. Asli namaz ke waqt par bhi dekhein.

## Jaan lein
- Alarm agle **30 din** ke lagte hain. Har baar app kholne par naye 30 din lag jate hain. 30 din se zyada app na kholein to alarm ruk jayenge.
- Jab bhi website update karein, GitHub par **Run workflow** dobara chalayein taake APK naya ban jaye.
- Ye **test (debug) APK** hai, dosto ko WhatsApp se bhej sakte hain. Play Store ke liye alag taiyari chahiye.
- Xiaomi/Redmi par agar phir bhi azan na baje: Settings, Apps, Noor, Battery: **No restrictions**, aur **Autostart ON**.
- Kisi step par laal ❌ aaye to us step ka naam aur screenshot bhej dein.
